'use client'

import { useState } from 'react'
import { Loader2 } from 'lucide-react'
import { useQueryClient } from '@tanstack/react-query'
import type { Queja } from '@/lib/types'
import { useQuejas } from '@/lib/queries/useQuejas'
import { queryKeys } from '@/lib/queries/queryKeys'
import { useAuthStore } from '@/lib/store/auth-store'
import Badge from '@/components/ui/Badge'
import PageHeader from '@/components/ui/PageHeader'
import EmptyState from '@/components/ui/EmptyState'
import Pagination from '@/components/ui/Pagination'
import QuejaColaboradorPanel from './components/QuejaColaboradorPanel'
import { prioridadVariant, estadoVariant } from '@/lib/constants/variants'
export default function MisQuejasPage() {
  const user = useAuthStore((s) => s.user)
  const [page, setPage] = useState(0)
  const pageSize = 25
  const [panelOpen, setPanelOpen] = useState<Queja | null>(null)
  const queryClient = useQueryClient()

  const { data, isLoading: loading, error, refetch } = useQuejas(
    {
      page,
      pageSize,
      responsableId: user?.id,
    },
    !!user?.id,
  )
  const quejas = data?.data ?? []
  const totalCount = data?.count ?? 0
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize))

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.quejas })
    queryClient.invalidateQueries({ queryKey: queryKeys.dashboard })
  }

  return (
    <div className="flex h-full w-full flex-col">
      <PageHeader title="Mis Quejas" description="Quejas asignadas a tu usuario para procesamiento" />

      {/* Tabla a ancho completo (nunca se mueve ni encoge).
          Con el panel abierto se recorta 500px a la derecha (las columnas quedan bajo el panel)
          y aparece el scrollbar horizontal único para desplazarlas. */}
      <div
        className={`flex-1 min-w-0 monday-scroll overflow-x-auto overflow-y-auto rounded-lg border border-qms-border pb-4 ${panelOpen ? 'mr-[calc(500px-16px)]' : 'monday-scroll-no-x'}`}
      >
          {loading ? (
            <div className="flex min-h-[300px] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-gray-400" /></div>
          ) : error ? (
            <div className="flex min-h-[300px] flex-col items-center justify-center gap-3">
              <p className="text-sm text-gray-500">No se pudieron cargar tus quejas.</p>
              <button onClick={() => refetch()} className="rounded-button border-0 bg-qms-primary px-3 py-1.5 text-sm font-medium text-white hover:bg-qms-primary-hover">Reintentar</button>
            </div>
          ) : (
            <table className={`w-full text-left text-sm select-text ${panelOpen ? 'min-w-[calc(100%+484px)]' : 'min-w-[1200px]'}`}>
              <thead>
                <tr className="sticky top-0 z-10 bg-qms-header">
                  <th className="px-3 py-2.5 text-left font-semibold text-white whitespace-nowrap">Folio</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-white whitespace-nowrap min-w-[160px]">Cliente</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-white whitespace-nowrap min-w-[140px]">Categoría</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-white whitespace-nowrap">Prioridad</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-white whitespace-nowrap">Estado</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-white whitespace-nowrap">Límite investigación</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-white whitespace-nowrap">Fecha</th>
                </tr>
              </thead>
              <tbody>
                {quejas.length === 0 ? (
                  <EmptyState message="No tienes quejas asignadas" />
                ) : (
                  quejas.map((q) => (
                    <tr key={q.id} onClick={() => setPanelOpen(q)} className="transition-colors cursor-pointer border-b border-gray-200 hover:bg-gray-50">
                      <td className="px-3 py-2.5 align-middle whitespace-nowrap"><span className="font-mono text-sm font-medium">{q.folio}</span></td>
                      <td className="px-3 py-2.5 align-middle whitespace-nowrap font-medium text-gray-900">{q.cliente_nombre}</td>
                      <td className="px-3 py-2.5 align-middle whitespace-nowrap text-gray-600">{q.categoria}</td>
                      <td className="px-3 py-2.5 align-middle whitespace-nowrap"><Badge variant={prioridadVariant[q.prioridad] || 'gray'}>{q.prioridad}</Badge></td>
                      <td className="px-3 py-2.5 align-middle whitespace-nowrap"><Badge variant={estadoVariant[q.estado] || 'gray'}>{q.estado}</Badge></td>
                      <td className="px-3 py-2.5 align-middle text-gray-500 whitespace-nowrap">
                        {q.fecha_limite_investigacion ? new Date(q.fecha_limite_investigacion).toLocaleDateString('es-ES') : '—'}
                      </td>
                      <td className="px-3 py-2.5 align-middle text-gray-500 whitespace-nowrap">{new Date(q.fecha).toLocaleDateString('es-ES')}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}
      </div>

      <QuejaColaboradorPanel queja={panelOpen} onClose={() => setPanelOpen(null)} onUpdated={invalidate} />

      {!loading && (
        <Pagination page={page} count={totalCount} busy={loading} onChange={setPage} />
      )}
    </div>
  )
}